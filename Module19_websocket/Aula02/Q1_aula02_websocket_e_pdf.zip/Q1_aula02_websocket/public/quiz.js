export function createQuiz() {
    const state = {
        users: {},
        questions: {},
    };

    /*
    ex:
     const state = {
        users: { lets: { userId: "0101", username: "lets" } },
        questions: {
            12345: {
                text: "1+1 = 3?",
                author: "lets",
                totalYes: 10,
                totalNo: 5,
            },
        },
    };
    
    */

    // applying observer pattern
    const observers = [];

    function subscribe(observerFunction) {
        observers.push(observerFunction);
    }

    function notifyAll(command) {
        for (const observerFunction of observers) {
            observerFunction(command);
        }
    }

    function addUser(command) {
        const newUserId = command.userId;
        const newUsername = command.username;
        state.users[newUsername] = { userId: newUserId, username: newUsername };

        notifyAll({
            type: "add-user",
            userId: newUserId,
            username: newUsername,
        });
    }

    function addQuestion(command) {
        const questionId = command.questionId;
        const text = command.text;
        const author = command.author;
        const totalYes = command.totalYes;
        const totalNo = command.totalNo;

        state.questions[questionId] = {
            text: text,
            author: author,
            totalYes: totalYes,
            totalNo: totalNo,
        };

        notifyAll({
            type: "add-question",
            questionId: questionId,
            text: text,
            author: author,
            totalYes: totalYes,
            totalNo: totalNo,
        });
    }

    function updateVoteCount(command) {
        const questionId = command.questionId;
        const votingOption = command.votingOption;
        if (votingOption === "yes") {
            state.questions[questionId].totalYes++;
        } else if (votingOption === "no") {
            state.questions[questionId].totalNo++;
        }
        notifyAll({
            type: "update-vote",
            questionId: questionId,
            votingOption: votingOption,
        });
    }

    function setState(newState) {
        Object.assign(state, newState);
    }

    function removeUser(command) {
        const username = command.username;
        delete state.users[username];
        notifyAll({
            type: "remove-user",
            username: username,
        });
    }

    return {
        state,
        subscribe,
        addUser,
        addQuestion,
        updateVoteCount,
        setState,
        removeUser,
    };
}
