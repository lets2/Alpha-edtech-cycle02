//const ws = new WebSocket("ws://localhost:3002");
import { io } from "./socket.io.min.js";
import { createQuiz } from "./quiz.js";

/**
O que as variáveis globais representam no HTML:

        ┌───────────────┐     ┌─────────────┐
        │ usernameInput │     │ enterButton │
        └───────────────┘     └─────────────┘

        gameContainer
┌─────────────────────────────────────────────────┐
│                                                 │
│ ┌──────────────────────┐ ┌────────────────────┐ │
│ │ newQuestionInput     │ │addQuestionButton   │ │
│ └──────────────────────┘ └────────────────────┘ │
│                                                 │
│               questionsContainer                │
│  ┌───────────────────────────────────────────┐  │
│  │                                           │  │
│  │   ┌───────────────────────────────┐       │  │
│  │   │                               │       │  │
│  │   │         <questão>             │       │  │
│  │   └───────────────────────────────┘       │  │
│  │                                           │  │
│  │   ┌───────────────────────────────┐       │  │
│  │   │                               │       │  │
│  │   │         <questão>             │       │  │
│  │   └───────────────────────────────┘       │  │
│  │                                           │  │
│  │                   .                       │  │
│  │                   .                       │  │
│  │                   .                       │  │
│  └───────────────────────────────────────────┘  │
│                                                 │
└─────────────────────────────────────────────────┘
 */

const usernameInput = document.getElementById("username");
const enterButton = document.getElementById("enterButton");

const gameContainer = document.getElementById("gameContainer");

const newQuestionInput = document.getElementById("newQuestion");
const addQuestionButton = document.getElementById("addQuestionButton");

const questionsContainer = document.getElementById("questions");

// ===========================================
// FUNÇÕES UTILITÁRIAS PARA MANIPULAR O DOM
// ===========================================

/**
 *
 * Adiciona uma nova questão ao HTML.
 *
 * @param {{id: string, author: string, text: string, yes: number, no: number}} question - Objeto representando uma questão.
 * @param {() => void} clickedYes - Função de clique do botão "Sim" da questão. Será invocada sem argumentos.
 * @param {() => void} clickedNo - Função de clique do botão "Não" da questão. Será invocada sem argumentos.
 */
function addQuestionToUI(question, clickedYes, clickedNo) {
    if (typeof question.id !== "string") {
        const errorString = `Tentou adicionar à UI uma questão, mas question.id não é uma string`;
        console.error(errorString);
        console.error("question: ", question);
        alert(errorString);
        return;
    }

    if (typeof clickedYes !== "function") {
        const errorString = `Tentou adicionar à UI uma questão, mas clickedYes não é uma função`;
        console.error(errorString);
        alert(errorString);
        return;
    }

    if (typeof clickedNo !== "function") {
        const errorString = `Tentou adicionar à UI uma questão, mas clickedNo não é uma função`;
        console.error(errorString);
        alert(errorString);
        return;
    }

    if (
        questionsContainer.querySelector(`[data-question_id="${question.id}"]`)
    ) {
        const errorString = `Tentou adicionar à UI uma questão com id ${question.id}, mas esse id já existe na UI`;
        console.error(errorString);
        console.error("question: ", question);
        alert(errorString);
        return;
    }

    if (typeof question.author !== "string") {
        const errorString = `Tentou adicionar à UI uma questão, mas question.author não é uma string`;
        console.error(errorString);
        console.error("question: ", question);
        alert(errorString);
        return;
    }

    if (typeof question.text !== "string") {
        const errorString = `Tentou adicionar à UI uma questão, mas question.text não é uma string`;
        console.error(errorString);
        console.error("question: ", question);
        alert(errorString);
        return;
    }

    if (typeof question.yes !== "number") {
        const errorString = `Tentou adicionar à UI uma questão, mas question.yes não é um número`;
        console.error(errorString);
        console.error("question: ", question);
        alert(errorString);
        return;
    }

    if (typeof question.yes !== "number") {
        const errorString = `Tentou adicionar à UI uma questão, mas question.no não é um número`;
        console.error(errorString);
        console.error("question: ", question);
        alert(errorString);
        return;
    }

    const questionDiv = document.createElement("div");
    questionDiv.dataset["question_id"] = question.id;
    questionDiv.innerHTML = `
    <p><span>Autor:</span> ${question.author}</p>
    <p><span>Pergunta:</span> ${question.text}</p>
    <button class="yes">Sim (${question.yes})</button>
    <button class="no">Não (${question.no})</button>
  `;
    questionDiv
        .querySelector(".yes")
        .addEventListener("click", (event) => clickedYes(event));
    questionDiv
        .querySelector(".no")
        .addEventListener("click", (event) => clickedNo(event));

    questionsContainer.prepend(questionDiv);
}

/**
 *
 * Atualiza a contagem de um dos botões de uma certa questão no HTML (a questão já deve
 * existir no HTML)
 *
 * @param {{questionId: string, answer: "yes" | "no", count: number}} update - Objeto
 * representando a nova contagem de uma das respostas de uma questão
 */
function updateVoteCountUI(update) {
    const questionDiv = questionsContainer.querySelector(
        `[data-question_id="${update.questionId}"]`
    );

    if (!questionDiv) {
        const errorString = `Tentou atualizar voto da questão com id ${update.questionId}, mas ela não estava presente no HTML`;
        console.error(errorString);
        console.error("update: ", update);
        alert(errorString);
        return;
    }

    if (update.answer !== "yes" && update.answer !== "no") {
        const errorString = `Tentou atualizar voto da questão com id ${update.questionId} na resposta "${update.answer}", mas a resposta só pode ser "yes" ou "no"`;
        console.error(errorString);
        console.error("update: ", update);
        alert(errorString);
        return;
    }

    if (typeof update.count !== "number") {
        const errorString = `Tentou atualizar voto da questão com id ${update.questionId}, mas a propriedade update.count não é um número`;
        console.error(errorString);
        console.error("update: ", update);
        alert(errorString);
        return;
    }

    const button = questionDiv.querySelector(`.${update.answer}`);
    button.textContent = `${update.answer === "yes" ? "Sim" : "Não"} (${
        update.count
    })`;
}

function displayQuizContainer() {
    gameContainer.style.display = "block";
}

// =======================================
// Websocket client side
// =======================================

const quiz = createQuiz();

const socket = io();

enterButton.addEventListener("click", () => {
    if (usernameInput.value !== "") {
        const newUser = { type: "register", username: usernameInput.value };
        socket.emit("register", newUser);
    }
});

socket.on("register-success", (message) => {
    if (socket.id === message.userId) {
        alert(message.content);
        displayQuizContainer();
    }
});

socket.on("register-fail", (message) => {
    if (socket.id === message.userId) {
        alert(message.content);
    }
});

socket.on("add-user", (command) => {
    console.log(`Receiving ${command.type} -> ${command.username}`);
    quiz.addUser(command);
});

socket.on("remove-user", (command) => {
    console.log(`Receiving ${command.type} -> ${command.username}`);
    quiz.removeUser(command);
});

addQuestionButton.addEventListener("click", () => {
    if (newQuestionInput.value !== "") {
        const newQuestion = {
            type: "add-question",
            text: newQuestionInput.value,
        };
        socket.emit("add-question", newQuestion);
    }
});

socket.on("add-question", (command) => {
    console.log(`Receiving ${command.type} -> ${command.text}`);
    quiz.addQuestion(command);

    addQuestionToUI(
        {
            id: command.questionId,
            author: command.author,
            text: command.text,
            yes: command.totalYes,
            no: command.totalNo,
        },
        (event) => {
            const questionId = event.target.parentNode.dataset.question_id;
            console.log(event.target.parentNode.dataset.question_id);
            updateVoteCountInServer(questionId, "yes");
        },
        (event) => {
            const questionId = event.target.parentNode.dataset.question_id;
            console.log(event.target.parentNode.dataset.question_id);
            updateVoteCountInServer(questionId, "no");
        }
    );
});

function updateVoteCountInServer(questionId, votingOption) {
    socket.emit("update-vote", {
        type: "update-vote",
        questionId: questionId,
        votingOption: votingOption,
    });
}

socket.on("update-vote", (command) => {
    console.log(
        `Receiving ${command.type} -> ${command.questionId} - ${command.votingOption}`
    );
    quiz.updateVoteCount(command);
    //updateUI:
    const questionId = command.questionId;
    const answer = command.votingOption;
    const count =
        answer === "yes"
            ? quiz.state.questions[questionId].totalYes
            : quiz.state.questions[questionId].totalNo;

    const statusQuestion = {
        questionId: questionId,
        answer: answer,
        count: count,
    };
    updateVoteCountUI(statusQuestion);
});

socket.on("setup-old-questions", (state) => {
    quiz.setState(state);
    const questions = quiz.state.questions;
    for (let questionId in questions) {
        addQuestionToUI(
            {
                id: questionId,
                author: questions[questionId].author,
                text: questions[questionId].text,
                yes: questions[questionId].totalYes,
                no: questions[questionId].totalNo,
            },
            (event) => {
                const questionId = event.target.parentNode.dataset.question_id;
                updateVoteCountInServer(questionId, "yes");
            },
            (event) => {
                const questionId = event.target.parentNode.dataset.question_id;
                updateVoteCountInServer(questionId, "no");
            }
        );
    }
});
