// server.js
import express from "express";
import http from "http";
//const WebSocket = require("ws");
import { Server } from "socket.io";
import { createQuiz } from "./public/quiz.js";

import { v4 as uuid_v4 } from "uuid";

const app = express();
app.use("/", express.static("public"));
const server = http.createServer(app);
const sockets = new Server(server);

// create a instance of quiz on server side
const quiz = createQuiz();

quiz.subscribe((command) => {
    console.log(`> Emitting ${command.type}`);
    sockets.emit(command.type, command);
});

sockets.on("connection", (socket) => {
    const userId = socket.id;
    let username = "";
    console.log(`> User connected on server with id: ${userId}`);

    socket.on("disconnect", (socket) => {
        quiz.removeUser({ username: username });
        console.log(`> User disconnected: ${username}`);
    });

    socket.on("register", (newUser) => {
        if (newUser.username in quiz.state.users) {
            const message = {
                type: "register-fail",
                userId: userId,
                content: `Já existe um usuário com o username: ${newUser.username}. Insira um outro username`,
            };
            socket.emit("register-fail", message);
        } else {
            username = newUser.username;
            quiz.addUser({
                userId: userId,
                username: username,
            });
            const message = {
                type: "register-success",
                userId: userId,
                content: `Usuário ${newUser.username} cadastrado com sucesso`,
            };
            socket.emit("register-success", message);

            // question: considerando que quero manter tudo atualizado,
            // estou mandando tudo, mas teoricamente, somente as perguntas
            // são relevantes
            socket.emit("setup-old-questions", quiz.state);
        }
    });

    socket.on("add-question", (message) => {
        const questionId = uuid_v4();

        const newQuestion = {
            questionId: questionId,
            text: message.text,
            author: username,
            totalYes: 0,
            totalNo: 0,
        };
        quiz.addQuestion(newQuestion);
    });

    socket.on("update-vote", (message) => {
        const updateVote = {
            questionId: message.questionId,
            votingOption: message.votingOption,
        };
        quiz.updateVoteCount(updateVote);
    });
});

const port = 3002;

server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
